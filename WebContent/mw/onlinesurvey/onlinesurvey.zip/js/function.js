$(function(){
	$("#btnpre").on("click",function(){prePage()});
    $("#btnnext").on("click",function(){nextPage()});
	$("#btnsecond").on("click",function(){
		$("#first").hide();
		$("#second").show();
		});

});

function showpage(n,type)
{
	$('.survey div').each(function(index){
		$(this).hide();
	});
	//alert(type+"--"+currentpage);
	//当前问答DIV
	if(type==0){
		var tmp= $.cookie('p_'+n); 
		//alert(n+"--"+tmp);
		setval(n,tmp);
		$('.survey div').eq(n).show();
	}
	else
	{
	  getval(n);
	}
}
function getval(n)
{
    var obj = $('.survey div').eq(n - 1);
    var _input = obj.find("input,textarea");
    if (_input) {
        var type = _input.attr("type");
	    var check = _input.attr("check");
        if (type == "radio") {
			var sVal = obj.find("input[type=radio]:checked").val();
			//alert(check+"_"+sVal);
			if (check) {
				var sReg = check;
				var sTemp = sVal != undefined ? "0" : "";
				var reg = new RegExp(sReg, "i");
				if (!reg.test(sTemp)) {
					lhgdialog.alert(_input.attr("warning"));
					obj.show();
					currentpage--;
					return false;
				}
			}
			$.cookie('p_' + (n - 1), sVal);
			if ($('.survey div').eq(n).find("input[type=radio]")) {
				var tmp = $.cookie('p_' + n);
				if (tmp) $('.survey div').eq(n).find("input[value='+tmp+']").attr('checked', 'checked');  
			}
			$('.survey div').eq(n).show();
			return true;
        }
        else {
            var sVal = _input.attr("value");
            if (check) {
                var sReg = check;
                var reg = new RegExp(sReg, "i");
                if (sVal == "" || !reg.test(sVal)) {
                    lhgdialog.alert(_input.attr("warning"));
                    obj.show();
                    currentpage--;
                    return false;
                }
            }
            $.cookie('p_' + (n - 1), sVal);
            if ($('.survey div').eq(n).find("textarea")) {
                var tmp = $.cookie('p_' + n);
                if (tmp) $('.survey div').eq(n).find("textarea").attr('value', tmp);
            }
            $('.survey div').eq(n).show();
            return true;
        }
        
    }
}
function setval(n,val)
{
	var obj=$('.survey div').eq(n);
	var _input=obj.find("input");
	if(_input!=undefined)
	{
		obj.find("input[value='+val+']").attr('checked','checked');
		return;
	}
	_input=obj.find("textarea");
	if(_input!=undefined)
	{
		obj.find("textarea").attr('value',val);
	}
}
//上一页
function prePage()
{
	var n=parseInt(currentpage);
	if(n>0){
	   setBtn("btnpre","",0);	
	   currentpage--;
	   showpage(n-1,0);
	   saveProgress();
	}
	else
	{
		//首页
		window.location.href=homeurl;
		setBtn("btnpre","",1);
	}
}
//下一页
function nextPage()
{
	var len=$('.survey div').length;
	var n=parseInt(currentpage)+1;
	if(n>len-1)
	{
		$(".loading").show();
		//数据保存
		//alert(path+"/vote/GetResult.aspx?t="+ (new Date()).getTime());
		//$("#VWVoteForm").attr("action",path+"/vote/GetResult.aspx?t="+ (new Date()).getTime());
		$("#VWVoteForm").submit();
		setBtn("btnnext","",1);
	}
	else{
	  setBtn("btnnext","",0);
	  currentpage++;
	  showpage(n,1);
	  saveProgress();
	}
}

function setBtn(id,css,status)
{     
	$('#'+id).toggleClass(css);
}
//完成进度
function saveProgress()
{
	//$("#showproess").html((currentpage+1)+"/"+totalpage);
}